/* Public API regression test for the floating-point spreading scan.
   Link with --wrap=spreading_statistics_neon and test_spreading_reference.c.
   For SVE builds also wrap spreading_statistics_sve256. */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "opus.h"
#include "bands.h"
#include "cpu_support.h"
#include "test_spreading_reference.h"

#if !defined(FIXED_POINT) && defined(OPUS_ARM_MAY_HAVE_NEON_INTR) && !defined(FUZZING)

static int reference_mode;
static unsigned long optimized_calls, original_calls;
static unsigned long optimized_coefficients, original_coefficients;

#if defined(OPUS_ARM_MAY_HAVE_SVE256_INTR)
#include <sys/auxv.h>
#include <asm/hwcap.h>
#include <sys/prctl.h>
static int test_sve256;
static unsigned long sve_calls;
#endif

typedef void (*spreading_scan)(const CELTMode *, const celt_norm *,
      int, int, int, int, const int *, int *, int *, int *);

static void compare_spreading_scan(spreading_scan implementation,
      const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum)
{
   unsigned long coefficients = 0;
   int i;
   for (i = 0; i < end; i++) {
      int N = M*(m->eBands[i+1] - m->eBands[i]);
      if (N > 8) coefficients += (unsigned long)N*C;
   }
   if (reference_mode) {
      original_calls++;
      original_coefficients += coefficients;
      spreading_statistics_original(m, X, update_hf, end, C, M, spread_weight,
                                    sum, nb_bands, hf_sum);
   } else {
      optimized_calls++;
      optimized_coefficients += coefficients;
      implementation(m, X, update_hf, end, C, M, spread_weight, sum, nb_bands, hf_sum);
   }
}

void __real_spreading_statistics_neon(const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum);

void __wrap_spreading_statistics_neon(const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum)
{
   compare_spreading_scan(__real_spreading_statistics_neon, m, X, update_hf,
         end, C, M, spread_weight, sum, nb_bands, hf_sum);
}

#if defined(OPUS_ARM_MAY_HAVE_SVE256_INTR)
void __real_spreading_statistics_sve256(const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum);

void __wrap_spreading_statistics_sve256(const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum)
{
   if (test_sve256) {
      sve_calls++;
      compare_spreading_scan(__real_spreading_statistics_sve256, m, X, update_hf,
            end, C, M, spread_weight, sum, nb_bands, hf_sum);
   } else {
      /* Let the kernel fall through to the wrapped NEON scan at 128 bits. */
      __real_spreading_statistics_sve256(m, X, update_hf, end, C, M,
            spread_weight, sum, nb_bands, hf_sum);
   }
}
#endif

static void fail(const char *message, int channels, int frame_size, int frame)
{
   fprintf(stderr, "FAIL: %s (channels=%d frame_size=%d frame=%d)\n",
           message, channels, frame_size, frame);
   exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
   static const int frame_sizes[] = {120, 480, 960};
   opus_uint32 seed = 42;
   int channels, scenario;
   const char *label = "NEON";
#if defined(OPUS_ARM_MAY_HAVE_SVE256_INTR)
   test_sve256 = argc == 2 && strcmp(argv[1], "sve256") == 0;
   if (argc != 1 && !test_sve256)
      return EXIT_FAILURE;
   if (getauxval(AT_HWCAP) & HWCAP_SVE) {
      int bytes = test_sve256 ? 32 : 16;
      int actual = prctl(PR_SVE_SET_VL, bytes, 0, 0, 0);
      if (actual < 0 || (actual & PR_SVE_VL_LEN_MASK) != bytes) {
         puts("SKIP: requested SVE vector length unavailable");
         return 77;
      }
   } else if (test_sve256) {
      puts("SKIP: CPU does not support SVE");
      return 77;
   }
   if (test_sve256)
      label = "SVE256";
#else
   (void)argv;
   if (argc != 1)
      return 77;
#endif
#if defined(OPUS_HAVE_RTCD)
   if (opus_select_arch() < OPUS_ARCH_ARM_NEON) {
      puts("SKIP: CPU does not support NEON");
      return 77;
   }
#endif
   for (channels = 1; channels <= 2; channels++) {
      for (scenario = 0; scenario < 3; scenario++) {
         OpusEncoder *enc[2];
         OpusDecoder *dec[2];
         opus_int16 pcm[1920], decoded[2][1920];
         unsigned char packet[2][1500];
         unsigned long before_optimized = optimized_calls;
         unsigned long before_original = original_calls;
         int frame_size = frame_sizes[scenario];
         int i, frame;
         for (i = 0; i < 2; i++) {
            int error;
            enc[i] = opus_encoder_create(48000, channels,
                                        OPUS_APPLICATION_RESTRICTED_CELT, &error);
            if (!enc[i] || error != OPUS_OK)
               fail("encoder creation", channels, frame_size, -1);
            dec[i] = opus_decoder_create(48000, channels, &error);
            if (!dec[i] || error != OPUS_OK)
               fail("decoder creation", channels, frame_size, -1);
            if (opus_encoder_ctl(enc[i], OPUS_SET_BITRATE(64000*channels)) != OPUS_OK ||
                opus_encoder_ctl(enc[i], OPUS_SET_COMPLEXITY(5)) != OPUS_OK)
               fail("encoder configuration", channels, frame_size, -1);
         }
         for (frame = 0; frame < 50; frame++) {
            opus_uint32 encoder_range[2], decoder_range[2];
            int lengths[2], j;
            for (j = 0; j < frame_size*channels; j++) {
               seed = 1664525U*seed + 1013904223U;
               pcm[j] = (opus_int16)((int)(seed >> 16)/4 - 8192);
            }
            for (i = 0; i < 2; i++) {
               reference_mode = i;
               lengths[i] = opus_encode(enc[i], pcm, frame_size, packet[i],
                                        (opus_int32)sizeof(packet[i]));
               if (lengths[i] <= 0 || !(packet[i][0] & 0x80))
                  fail("encode did not produce a CELT packet", channels, frame_size, frame);
               if (opus_decode(dec[i], packet[i], lengths[i], decoded[i],
                               frame_size, 0) != frame_size)
                  fail("decode", channels, frame_size, frame);
               if (opus_encoder_ctl(enc[i], OPUS_GET_FINAL_RANGE(&encoder_range[i])) != OPUS_OK ||
                   opus_decoder_ctl(dec[i], OPUS_GET_FINAL_RANGE(&decoder_range[i])) != OPUS_OK ||
                   encoder_range[i] != decoder_range[i])
                  fail("encoder/decoder final range mismatch", channels, frame_size, frame);
            }
            if (lengths[0] != lengths[1] ||
                memcmp(packet[0], packet[1], (size_t)lengths[0]) != 0 ||
                memcmp(decoded[0], decoded[1], (size_t)frame_size*channels*sizeof(opus_int16)) != 0 ||
                encoder_range[0] != encoder_range[1])
               fail("optimized/original packet, PCM or final range mismatch", channels, frame_size, frame);
         }
         if (optimized_calls == before_optimized || original_calls == before_original)
            fail("spreading scan was not reached by both encoders", channels, frame_size, 50);
         for (i = 0; i < 2; i++) {
            opus_encoder_destroy(enc[i]);
            opus_decoder_destroy(dec[i]);
         }
      }
   }
   if (!optimized_coefficients || !original_coefficients || optimized_calls != original_calls ||
       optimized_coefficients != original_coefficients)
      fail("scan call/work counters differ or contain no work", 0, 0, 0);
#if defined(OPUS_ARM_MAY_HAVE_SVE256_INTR)
   if (test_sve256 && sve_calls != optimized_calls + original_calls)
      fail("unexpected spreading dispatch", 0, 0, 0);
#endif
   printf("PASS: 300 paired CELT frames, mono/stereo, 2.5/10/20 ms; "
          "packets, PCM and final ranges exactly match original scan; "
          "%s calls=%lu coefficients=%lu original calls=%lu coefficients=%lu\n",
          label, optimized_calls, optimized_coefficients, original_calls, original_coefficients);
   return EXIT_SUCCESS;
}

#else

int main(void)
{
   puts("SKIP: requires floating-point NEON without FUZZING");
   return 77;
}

#endif
