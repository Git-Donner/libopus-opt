/* Copyright (c) 2007-2008 CSIRO
   Copyright (c) 2007-2009 Xiph.Org Foundation
   Copyright (c) 2008-2009 Gregory Maxwell
   Written by Jean-Marc Valin and Gregory Maxwell */
/*
   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
   OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#if defined(OPUS_ARM_MAY_HAVE_SVE256_INTR) && !defined(FIXED_POINT)
#include <arm_sve.h>
#include "bands.h"

/* Honor the same cutoff switch and FPCR requirements as NEON v2. */
#ifndef OPUS_SPREAD_NEON_CUTOFFS
#define OPUS_SPREAD_NEON_CUTOFFS 1
#endif
#if OPUS_SPREAD_NEON_CUTOFFS && !defined(__FAST_MATH__)
#include "spreading_cutoffs.h"
static OPUS_INLINE int spreading_cutoffs_allowed(void)
{
   opus_uint64 fpcr;
   __asm__ __volatile__("mrs %0, fpcr" : "=r"(fpcr));
   /* RMode[23:22] must be RN; IOE,DZE,OFE,UFE,IXE,IDE must be clear. */
   return (fpcr & ((3UL << 22) | 0x9f00UL)) == 0;
}
#endif

/* The caller establishes Linux HWCAP_SVE. The kernel checks the current
   thread's vector length; the length can differ between calls. */
void spreading_statistics_sve256(const CELTMode *m, const celt_norm *X,
      int update_hf, int end, int C, int M, const int *spread_weight,
      int *sum, int *nb_bands, int *hf_sum)
{
   int c, i;
   int sum_acc = 0, nb_bands_acc = 0, hf_sum_acc = 0;
   const int N0 = M*m->shortMdctSize;
   const opus_int16 * OPUS_RESTRICT eBands = m->eBands;
   const svbool_t all = svptrue_b32();
   const svuint32_t one = svdup_n_u32(1);
#if OPUS_SPREAD_NEON_CUTOFFS && !defined(__FAST_MATH__)
   int cutoff_mode;
#endif

   if (svcntw()!=8)
   {
      spreading_statistics_neon(m, X, update_hf, end, C, M, spread_weight,
            sum, nb_bands, hf_sum);
      return;
   }

#if OPUS_SPREAD_NEON_CUTOFFS && !defined(__FAST_MATH__)
   cutoff_mode = spreading_cutoffs_allowed();
#endif
   c=0; do {
      for (i=0;i<end;i++)
      {
         int j;
         int tcount0, tcount1, tcount2, tmp;
         const int N = M*(eBands[i+1]-eBands[i]);
         const celt_norm * OPUS_RESTRICT x = X+M*eBands[i]+c*N0;
         svuint32_t count0, count1, count2;
         svbool_t active;
         if (N<=8)
            continue;
         count0 = count1 = count2 = svdup_n_u32(0);
         j=0;
         active = svwhilelt_b32_s32(j, N);
#if OPUS_SPREAD_NEON_CUTOFFS && !defined(__FAST_MATH__)
         if (cutoff_mode && N<=SPREADING_CUTOFF_MAX_N && spreading_cutoff_bits[N])
         {
            opus_uint32 bits = spreading_cutoff_bits[N];
            svfloat32_t a0 = svreinterpret_f32_u32(svdup_n_u32(bits));
            svfloat32_t a1 = svreinterpret_f32_u32(svdup_n_u32(bits-0x00800000U));
            svfloat32_t a2 = svreinterpret_f32_u32(svdup_n_u32(bits-0x01000000U));
            do {
               svfloat32_t ax = svabs_f32_x(active, svld1_f32(active, x+j));
               count0 = svadd_u32_m(svcmplt_f32(active, ax, a0), count0, one);
               count1 = svadd_u32_m(svcmplt_f32(active, ax, a1), count1, one);
               count2 = svadd_u32_m(svcmplt_f32(active, ax, a2), count2, one);
               j += 8;
               active = svwhilelt_b32_s32(j, N);
            } while (svptest_any(all, active));
         } else
#endif
         {
            do {
               svfloat32_t v = svld1_f32(active, x+j);
               svfloat32_t x2N = svmul_n_f32_x(active, svmul_f32_x(active, v, v), (float)N);
               count0 = svadd_u32_m(svcmplt_n_f32(active, x2N, 0.25f), count0, one);
               count1 = svadd_u32_m(svcmplt_n_f32(active, x2N, 0.0625f), count1, one);
               count2 = svadd_u32_m(svcmplt_n_f32(active, x2N, 0.015625f), count2, one);
               j += 8;
               active = svwhilelt_b32_s32(j, N);
            } while (svptest_any(all, active));
         }

         tcount0 = (int)svaddv_u32(all, count0);
         tcount1 = (int)svaddv_u32(all, count1);
         tcount2 = (int)svaddv_u32(all, count2);
         tmp = (2*tcount2 >= N) + (2*tcount1 >= N) + (2*tcount0 >= N);
         if (update_hf && i>m->nbEBands-4)
            hf_sum_acc += celt_udiv(32*(tcount0+tcount1), N);
         sum_acc += tmp*spread_weight[i];
         nb_bands_acc += spread_weight[i];
      }
   } while (++c<C);

   *sum = sum_acc;
   *nb_bands = nb_bands_acc;
   *hf_sum = hf_sum_acc;
}
#endif /* Float AArch64 SVE256. */
