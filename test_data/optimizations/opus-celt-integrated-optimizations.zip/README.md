# libopus CELT 联合优化包

基于 Xiph Opus 提交 0145a6248c2171bb6c4e03fb54fe016b5123e37e。files/ 内有相对于这个原始版本的 30 个新增或修改文件，包含 16 个新增文件和 14 个修改文件。各组件对同一路径的修改已合并。

- **PVQ 搜索**同时包含原 NEON 和最新版 256 位 SVE 内核。运行时检查 Linux HWCAP 和当前线程向量长度。SVE 扫描要求 N 至少为 8，其他情况走 NEON。
- **音高搜索**包含第二版 find_best_pitch 优化。粗搜后直接遍历两个细搜窗口，间隙的能量差使用 128 位 NEON 计算。
- **spreading_decision**包含原 NEON V2 和本次新增的 256 位 SVE 统计内核。两者共用精确幅值阈值及其允许条件。无 SVE 或向量长度不为 256 位时使用 NEON。
- **exp_rotation**包含 exp_rotation1 的步长 1 寄存器驻留和步长 2、4 NEON 路径，以及上层 c、s 系数缓存。每个浮点 CELT 编解码状态有各自的 768 字节缓存。

## 合入源码

将解压后 files/ 下的文件按相对路径放进同一基线的完整源码根目录。也可以在干净源码根目录应用总补丁。

```bash
git apply --check "$PKG/opus-celt-integrated.patch"
git apply "$PKG/opus-celt-integrated.patch"
```

PKG 指向解压目录。SHA256SUMS 用于验证 files/ 内容。

## 构建

在合并后的干净源码根目录重新生成 Autotools 构建文件。标准浮点构建可直接运行 autoreconf，避免 autogen.sh 的模型下载步骤。

```bash
autoreconf -isf

CC=gcc \
CFLAGS="-O3 -march=armv8-a -fno-semantic-interposition -fvisibility=hidden" \
./configure --disable-shared --enable-static --disable-fixed-point --enable-sve

make -j8
make check -j8
```

这里的全局 armv8-a 让同一套库能运行在具备 NEON 的无 SVE AArch64 机器上。构建系统单独给两个 SVE 源文件附加可扩展向量编译参数。用 --disable-sve 可构建 NEON 对照。CMake 的对应选项是 -DOPUS_ARM_SVE=ON 或 OFF。

如沿用全局 -march=armv8.2-a+sve，编译器也可能在其他源文件生成 SVE，整库适用于支持该指令集的机器。如使用 -ffp-contract=off，和原 PVQ 全 SVE 包一样同时加 -DOPUS_PVQ_SVE_NO_FMA，以配合 NEON 参考的乘加舍入。重新链接测试框架后再测静态库。

## 验证

- GCC 14.2 AArch64 交叉构建下，Autotools 的启用和禁用 SVE 两种静态浮点库均通过构建。CMake 下的六项 spreading、PVQ 和派发测试全部通过，x86 上游 CTest 五项全部通过。
- 新的 spreading 内核在 256 位环境逐项通过 56,532 例，含线程内 VL 修改。无 SVE、128 位、512 位各通过 56,464 例回退验证。覆盖阈值临界点、非默认舍入、保护页、关闭阈值查表及 UBSan。
- 同一个 ARMv8-A 浮点 ELF 在无 SVE、VL=128 位和 VL=256 位下跑 180 个 CELT、SILK、HYBRID 用例，每种比对 15,840 帧。编码包、编解码最终 range 和解码 PCM 逐位一致。256 位运行实际进入了 PVQ 和 spreading 的 SVE 内核。在单独验证中，x86 浮点、ARM 定点以及仅把 PVQ 强制设为标量的 ARM 浮点路径与原始库逐位一致。
- 全局 -march=armv8.2-a+sve 的构建另在固定 VL=256 位时对照 SVE 和强制 NEON，15,840 帧逐位一致。用不同 VL 跑全局 +sve 构建时，原始库和合并库都观察到个别解码 PCM 样本相差 1 LSB，编码包与最终 range 一致。比较时应固定线程向量长度。
- ARM PVQ 沿用此前 NEON 评分及其并列规则，PVQ SVE 逐位对照以 NEON 为参考。当前包中的 NEON 算子测试对标量比较时，在 8,824 例中有 817 例脉冲向量不同，最坏对齐损失为 0.01685245%。

ARM 正确性测试在 QEMU 中完成。Kunpeng 真机性能需使用各自重新链接的测试 worker 测量。
