# Opus AArch64 浮点 exp_rotation1 优化

基于 Git-Donner/libopus-opt 的 `d5f57452c1880c50ab0b8c0800810ba5da98923b`。修改 **`celt/vq.c`** 一个生产文件。压缩包同时提供完整文件、增量补丁和验证资料。

| 步长 | 正向扫描 | 反向扫描 |
|---|---|---|
| 1 | 把刚算出的右结果留在浮点寄存器，供下一次迭代作为左输入 | 把刚算出的左结果留在寄存器，供下一次迭代作为右输入 |
| 2 | NEON 每批并行算两对，右结果驻留到下一批 | NEON 每批并行算两对，左结果驻留到下一批 |
| 4 | NEON 每批并行算四对，右结果驻留到下一批 | NEON 每批并行算四对，左结果驻留到下一批 |
| 其他 | 沿用原来的标量循环 | 沿用原来的标量循环 |

## 为什么使用这几条路径

浮点构建的 `norm_scaleup` 和 `norm_scaledown` 在 `celt/vq.h` 里是空宏，没有需要执行的缩放。这两项只在定点构建中执行，本次仅修改浮点旋转。

对于步长 `s`，连续 `s` 个迭代的左右元素分别分布在两个相邻的连续区间，可以同时加载。例如 stride=4 时可同时处理 `(i,i+4)`、`(i+1,i+5)`、`(i+2,i+6)`、`(i+3,i+7)`。下一批会读到本批刚生成的结果，所以保留该依赖值在 NEON 寄存器中，避免先写回再读出。两路和四路分别使用 `float32x2_t` 和 `float32x4_t`。两趟扫描均在完整批次内向量化，余数走标量。反向扫描保留原来的起点 `len-2*stride-1`。

新增路径启用条件为 AArch64 浮点构建、有编译目标 NEON 支持并启用了 Opus 的 NEON intrinsics。现有 AArch64 + SVE 编译参数可以继续用。长度短到不足一批时执行对应的标量尾部。已有公开 `exp_rotation()` 的主步长固定为 1，生成的第二步长至少是 3，故 **stride=2 的实现通过了内部直接测试，但不会给当前公开入口带来端到端收益**。本次也在先前的 PVQ SVE256 补丁组合上通过了复验。

## 应用

推荐在你的 Opus 源码根目录打增量补丁，先检查能否应用。把路径改为实际解压位置。

```bash
cd /你的/opus源码目录
PATCH=/解压路径/opus-exp-rotation1-float-neon/exp-rotation1-float-neon.patch
patch --dry-run -p1 < "$PATCH" &&
patch -p1 < "$PATCH"
```

`files/celt/vq.c` 提供完整文件，适用于同基础源码。对于本地已改过的 `vq.c`，使用增量补丁以保留其他改动。

重新执行原来的构建流程即可。例如已配置好的 Autotools 构建：

```bash
make -j8
make check -j8
```

CMake 用户在自己的构建目录重新编译，例如 `cmake --build build -j8`。本次只有一个 C 源文件改动，构建参数沿用你的原有设置。性能对比时保持两边编译参数一致，尤其是浮点乘加收缩设置。建议重新链接你的 `opus_perf_test` 执行包，再进行同输入、同 CPU 的端到端测试。

## 复现 stride 专项验证

在 AArch64 浮点构建上，`validation/test_exp_rotation1.c` 通过包含实现文件访问内部函数，并与原来的标量访问顺序对照。以下命令在已经有 `config.h` 的 Autotools 就地构建目录执行。

```bash
CHECK=/解压路径/opus-exp-rotation1-float-neon/validation/test_exp_rotation1.c
gcc -O3 -std=c99 -march=armv8.2-a+sve \
  -DHAVE_CONFIG_H -DVAR_ARRAYS \
  -I. -Iinclude -Icelt -Isilk -Isilk/float -Idnn \
  -ffunction-sections -fdata-sections -Wl,--gc-sections \
  "$CHECK" -lm -o /tmp/test_exp_rotation1
/tmp/test_exp_rotation1
```

在关闭收缩的配置上复验时加入 `-ffp-contract=off`。如果使用外部 CMake 构建，`-I.` 换成实际构建目录，并传入该库使用的 NEON 编译定义。测试程序需要包含优化路径，若误用定点或不启用 NEON 会在编译时明确报错。详细结果见 `VALIDATION.md`。
