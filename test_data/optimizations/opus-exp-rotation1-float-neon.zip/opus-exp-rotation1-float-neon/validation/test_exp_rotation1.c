#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

/* Include the implementation only in this standalone test so it can
   access the internal stride=2 path, which exp_rotation() does not select. */
#include "vq.c"

#if !defined(OPUS_VQ_ROTATION_NEON) || defined(FIXED_POINT)
#error Build this verification program with the AArch64 floating-point NEON path enabled.
#endif

static uint32_t state = 42;

static float input_value(void)
{
    state = 1664525u * state + 1013904223u;
    return (float)((int)(state >> 16) - 32768) * (1.f / 32768);
}

/* Reference uses the original expressions and visit order. The reverse
   loop forms the pair address only when the index is valid. */
static __attribute__((noinline)) void reference(celt_norm *X, int len,
        int stride, opus_val16 c, opus_val16 s)
{
    int i;
    opus_val16 ms = NEG16(s);
    for (i=0;i<len-stride;i++)
    {
        celt_norm x1 = X[i];
        celt_norm x2 = X[i+stride];
        X[i+stride] = EXTRACT16(PSHR32(MAC16_16(MULT16_16(c, x2), s, x1), 15));
        X[i] = EXTRACT16(PSHR32(MAC16_16(MULT16_16(c, x1), ms, x2), 15));
    }
    for (i=len-2*stride-1;i>=0;i--)
    {
        celt_norm x1 = X[i];
        celt_norm x2 = X[i+stride];
        X[i+stride] = EXTRACT16(PSHR32(MAC16_16(MULT16_16(c, x2), s, x1), 15));
        X[i] = EXTRACT16(PSHR32(MAC16_16(MULT16_16(c, x1), ms, x2), 15));
    }
}

int main(void)
{
    const int strides[] = {1, 2, 4, 3, 5, 8, 11};
    const float coeffs[][2] = {
        {1.f, 0.f}, {0.f, 1.f}, {0.f, -1.f}, {-1.f, 0.f},
        {.9238795f, .3826834f}, {.9238795f, -.3826834f},
        {.70710677f, .70710677f}, {.70710677f, -.70710677f}
    };
    const long page = sysconf(_SC_PAGESIZE);
    enum { max_len = 256 };
    if (page < max_len * (long)sizeof(celt_norm))
        return 1;
    char *buffer = mmap(NULL, (size_t)page * 3, PROT_NONE,
                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (buffer == MAP_FAILED)
        return 1;
    if (mprotect(buffer+page, (size_t)page, PROT_READ | PROT_WRITE))
        return 1;

    unsigned cases = 0, unequal = 0;
    for (size_t si=0;si<sizeof(strides)/sizeof(strides[0]);si++)
    for (int len=si<3?0:2*strides[si]+1;len<=max_len;len++)
    for (size_t ci=0;ci<sizeof(coeffs)/sizeof(coeffs[0]);ci++)
    for (int tail=0;tail<2;tail++)
    {
        celt_norm ref[max_len];
        celt_norm *p = (celt_norm *)(buffer+page);
        if (tail)
            p = (celt_norm *)(buffer+2*page) - len;
        for (int i=0;i<len;i++) {
            float sample = i%23 == 0 ? -0.f : i%11 == 0 ? 0.f : input_value();
            ref[i] = p[i] = sample;
        }
        float c = coeffs[ci][0], s = coeffs[ci][1];
        reference(ref, len, strides[si], c, s);
        exp_rotation1(p, len, strides[si], c, s);
        if (memcmp(ref, p, (size_t)len * sizeof(*p))) {
            if (unequal < 12)
                for (int i=0;i<len;i++)
                    if (memcmp(p+i, ref+i, sizeof(*p))) {
                        printf("stride=%d len=%d c=%a s=%a pos=%d actual=%a ref=%a\n",
                               strides[si], len, (double)c, (double)s, i,
                               (double)p[i], (double)ref[i]);
                        break;
                    }
            ++unequal;
        }
        ++cases;
    }
    munmap(buffer, (size_t)page * 3);
    printf("exp_rotation1: %u/%u bit-exact cases; protected buffers at both ends\n",
           cases-unequal, cases);
    return unequal != 0;
}
