
/workspace/exp-rotation1-verify.WTErQy/arm-opt/CMakeFiles/opus.dir/celt/vq.c.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <exp_rotation1>:
       0:	1e21403f 	fneg	s31, s1
       4:	7100085f 	cmp	w2, #0x2
       8:	540012c0 	b.eq	260 <exp_rotation1+0x260>  // b.none
       c:	7100105f 	cmp	w2, #0x4
      10:	540004e0 	b.eq	ac <exp_rotation1+0xac>  // b.none
      14:	7100045f 	cmp	w2, #0x1
      18:	54001981 	b.ne	348 <exp_rotation1+0x348>  // b.any
      1c:	7100043f 	cmp	w1, #0x1
      20:	5400044d 	b.le	a8 <exp_rotation1+0xa8>
      24:	51000825 	sub	w5, w1, #0x2
      28:	91001004 	add	x4, x0, #0x4
      2c:	bd400011 	ldr	s17, [x0]
      30:	aa0003e2 	mov	x2, x0
      34:	8b254883 	add	x3, x4, w5, uxtw #2
      38:	d503201f 	nop
      3c:	d503201f 	nop
      40:	bd40045e 	ldr	s30, [x2, #4]
      44:	1e3f0bc3 	fmul	s3, s30, s31
      48:	1f110c03 	fmadd	s3, s0, s17, s3
      4c:	1e310831 	fmul	s17, s1, s17
      50:	1f1e4411 	fmadd	s17, s0, s30, s17
      54:	bc004443 	str	s3, [x2], #4
      58:	eb02007f 	cmp	x3, x2
      5c:	54ffff21 	b.ne	40 <exp_rotation1+0x40>  // b.any
      60:	bc255891 	str	s17, [x4, w5, uxtw #2]
      64:	7100083f 	cmp	w1, #0x2
      68:	54000200 	b.eq	a8 <exp_rotation1+0xa8>  // b.none
      6c:	928000e3 	mov	x3, #0xfffffffffffffff8    	// #-8
      70:	51000c22 	sub	w2, w1, #0x3
      74:	8b214863 	add	x3, x3, w1, uxtw #2
      78:	93407c41 	sxtw	x1, w2
      7c:	bc636819 	ldr	s25, [x0, x3]
      80:	bc617814 	ldr	s20, [x0, x1, lsl #2]
      84:	1e34083a 	fmul	s26, s1, s20
      88:	1f19681a 	fmadd	s26, s0, s25, s26
      8c:	1e3f0b39 	fmul	s25, s25, s31
      90:	1f146419 	fmadd	s25, s0, s20, s25
      94:	bc21789a 	str	s26, [x4, x1, lsl #2]
      98:	d1000421 	sub	x1, x1, #0x1
      9c:	3100043f 	cmn	w1, #0x1
      a0:	54ffff01 	b.ne	80 <exp_rotation1+0x80>  // b.any
      a4:	bd000019 	str	s25, [x0]
      a8:	d65f03c0 	ret
      ac:	71001c3f 	cmp	w1, #0x7
      b0:	5400278c 	b.gt	5a0 <exp_rotation1+0x5a0>
      b4:	7100103f 	cmp	w1, #0x4
      b8:	54ffff8d 	b.le	a8 <exp_rotation1+0xa8>
      bc:	5100102a 	sub	w10, w1, #0x4
      c0:	52800005 	mov	w5, #0x0                   	// #0
      c4:	d37e7ca2 	ubfiz	x2, x5, #2, #32
      c8:	110004a3 	add	w3, w5, #0x1
      cc:	8b020004 	add	x4, x0, x2
      d0:	bc626807 	ldr	s7, [x0, x2]
      d4:	bd401086 	ldr	s6, [x4, #16]
      d8:	1e27083a 	fmul	s26, s1, s7
      dc:	1f06681a 	fmadd	s26, s0, s6, s26
      e0:	1e3f08c6 	fmul	s6, s6, s31
      e4:	1f071806 	fmadd	s6, s0, s7, s6
      e8:	bd00109a 	str	s26, [x4, #16]
      ec:	bc226806 	str	s6, [x0, x2]
      f0:	6b0a007f 	cmp	w3, w10
      f4:	5400030a 	b.ge	154 <exp_rotation1+0x154>  // b.tcont
      f8:	91001043 	add	x3, x2, #0x4
      fc:	110008a5 	add	w5, w5, #0x2
     100:	8b030004 	add	x4, x0, x3
     104:	bc636818 	ldr	s24, [x0, x3]
     108:	bd401093 	ldr	s19, [x4, #16]
     10c:	1e380825 	fmul	s5, s1, s24
     110:	1f131405 	fmadd	s5, s0, s19, s5
     114:	1e3f0a73 	fmul	s19, s19, s31
     118:	1f184c13 	fmadd	s19, s0, s24, s19
     11c:	bd001085 	str	s5, [x4, #16]
     120:	bc236813 	str	s19, [x0, x3]
     124:	6b0a00bf 	cmp	w5, w10
     128:	5400016a 	b.ge	154 <exp_rotation1+0x154>  // b.tcont
     12c:	91002042 	add	x2, x2, #0x8
     130:	8b020003 	add	x3, x0, x2
     134:	bc626811 	ldr	s17, [x0, x2]
     138:	bd40107e 	ldr	s30, [x3, #16]
     13c:	1e310824 	fmul	s4, s1, s17
     140:	1f1e1004 	fmadd	s4, s0, s30, s4
     144:	1e3e0bfe 	fmul	s30, s31, s30
     148:	1f11781e 	fmadd	s30, s0, s17, s30
     14c:	bd001064 	str	s4, [x3, #16]
     150:	bc22681e 	str	s30, [x0, x2]
     154:	51002422 	sub	w2, w1, #0x9
     158:	7100085f 	cmp	w2, #0x2
     15c:	5400040d 	b.le	1dc <exp_rotation1+0x1dc>
     160:	4e040416 	dup	v22.4s, v0.s[0]
     164:	51002029 	sub	w9, w1, #0x8
     168:	4e0407f7 	dup	v23.4s, v31.s[0]
     16c:	53027c28 	lsr	w8, w1, #2
     170:	4e040435 	dup	v21.4s, v1.s[0]
     174:	d37e7d22 	ubfiz	x2, x9, #2, #32
     178:	51000d03 	sub	w3, w8, #0x3
     17c:	d1004045 	sub	x5, x2, #0x10
     180:	91008044 	add	x4, x2, #0x20
     184:	928007e6 	mov	x6, #0xffffffffffffffc0    	// #-64
     188:	8b050005 	add	x5, x0, x5
     18c:	8b040004 	add	x4, x0, x4
     190:	cb2350c6 	sub	x6, x6, w3, uxtw #4
     194:	3ce26819 	ldr	q25, [x0, x2]
     198:	51003021 	sub	w1, w1, #0xc
     19c:	aa0503e2 	mov	x2, x5
     1a0:	51000d08 	sub	w8, w8, #0x3
     1a4:	8b060084 	add	x4, x4, x6
     1a8:	3dc00042 	ldr	q2, [x2]
     1ac:	d1004042 	sub	x2, x2, #0x10
     1b0:	6e35dc54 	fmul	v20.4s, v2.4s, v21.4s
     1b4:	4e36cf34 	fmla	v20.4s, v25.4s, v22.4s
     1b8:	6e37df39 	fmul	v25.4s, v25.4s, v23.4s
     1bc:	3d800854 	str	q20, [x2, #32]
     1c0:	4e36cc59 	fmla	v25.4s, v2.4s, v22.4s
     1c4:	eb04005f 	cmp	x2, x4
     1c8:	54ffff01 	b.ne	1a8 <exp_rotation1+0x1a8>  // b.any
     1cc:	4b030822 	sub	w2, w1, w3, lsl #2
     1d0:	cb0813e8 	neg	x8, x8, lsl #4
     1d4:	51000442 	sub	w2, w2, #0x1
     1d8:	3ca56919 	str	q25, [x8, x5]
     1dc:	37fff662 	tbnz	w2, #31, a8 <exp_rotation1+0xa8>
     1e0:	d37e7c41 	ubfiz	x1, x2, #2, #32
     1e4:	8b010003 	add	x3, x0, x1
     1e8:	bc616803 	ldr	s3, [x0, x1]
     1ec:	bd401067 	ldr	s7, [x3, #16]
     1f0:	1e23083a 	fmul	s26, s1, s3
     1f4:	1f07681a 	fmadd	s26, s0, s7, s26
     1f8:	1e3f08e7 	fmul	s7, s7, s31
     1fc:	1f031c07 	fmadd	s7, s0, s3, s7
     200:	bd00107a 	str	s26, [x3, #16]
     204:	bc216807 	str	s7, [x0, x1]
     208:	34fff502 	cbz	w2, a8 <exp_rotation1+0xa8>
     20c:	d1001021 	sub	x1, x1, #0x4
     210:	8b010003 	add	x3, x0, x1
     214:	bc616806 	ldr	s6, [x0, x1]
     218:	bd401065 	ldr	s5, [x3, #16]
     21c:	1e260838 	fmul	s24, s1, s6
     220:	1f056018 	fmadd	s24, s0, s5, s24
     224:	1e3f08a5 	fmul	s5, s5, s31
     228:	1f061405 	fmadd	s5, s0, s6, s5
     22c:	bd001078 	str	s24, [x3, #16]
     230:	bc216805 	str	s5, [x0, x1]
     234:	7100045f 	cmp	w2, #0x1
     238:	54fff380 	b.eq	a8 <exp_rotation1+0xa8>  // b.none
     23c:	bd400004 	ldr	s4, [x0]
     240:	bd401013 	ldr	s19, [x0, #16]
     244:	1e240822 	fmul	s2, s1, s4
     248:	1f130802 	fmadd	s2, s0, s19, s2
     24c:	1e3f0a73 	fmul	s19, s19, s31
     250:	1f044c13 	fmadd	s19, s0, s4, s19
     254:	bd001002 	str	s2, [x0, #16]
     258:	bd000013 	str	s19, [x0]
     25c:	d65f03c0 	ret
     260:	71000c3f 	cmp	w1, #0x3
     264:	5400136c 	b.gt	4d0 <exp_rotation1+0x4d0>
     268:	52800005 	mov	w5, #0x0                   	// #0
     26c:	54fff1e1 	b.ne	a8 <exp_rotation1+0xa8>  // b.any
     270:	d37e7ca5 	ubfiz	x5, x5, #2, #32
     274:	8b050002 	add	x2, x0, x5
     278:	bc656802 	ldr	s2, [x0, x5]
     27c:	bd400843 	ldr	s3, [x2, #8]
     280:	1e220833 	fmul	s19, s1, s2
     284:	1f034c13 	fmadd	s19, s0, s3, s19
     288:	1e3f0863 	fmul	s3, s3, s31
     28c:	1f020c03 	fmadd	s3, s0, s2, s3
     290:	bd000853 	str	s19, [x2, #8]
     294:	bc256803 	str	s3, [x0, x5]
     298:	51001422 	sub	w2, w1, #0x5
     29c:	7100005f 	cmp	w2, #0x0
     2a0:	5400040d 	b.le	320 <exp_rotation1+0x320>
     2a4:	0e04041d 	dup	v29.2s, v0.s[0]
     2a8:	0e0407fc 	dup	v28.2s, v31.s[0]
     2ac:	0e04043b 	dup	v27.2s, v1.s[0]
     2b0:	51001029 	sub	w9, w1, #0x4
     2b4:	53017c28 	lsr	w8, w1, #1
     2b8:	d37e7d22 	ubfiz	x2, x9, #2, #32
     2bc:	51000d04 	sub	w4, w8, #0x3
     2c0:	d1002045 	sub	x5, x2, #0x8
     2c4:	91004043 	add	x3, x2, #0x10
     2c8:	928003e6 	mov	x6, #0xffffffffffffffe0    	// #-32
     2cc:	8b050005 	add	x5, x0, x5
     2d0:	8b030003 	add	x3, x0, x3
     2d4:	cb244cc6 	sub	x6, x6, w4, uxtw #3
     2d8:	fc626807 	ldr	d7, [x0, x2]
     2dc:	51001821 	sub	w1, w1, #0x6
     2e0:	aa0503e2 	mov	x2, x5
     2e4:	51000d08 	sub	w8, w8, #0x3
     2e8:	8b060063 	add	x3, x3, x6
     2ec:	fd400051 	ldr	d17, [x2]
     2f0:	d1002042 	sub	x2, x2, #0x8
     2f4:	2e3bde26 	fmul	v6.2s, v17.2s, v27.2s
     2f8:	0e3dcce6 	fmla	v6.2s, v7.2s, v29.2s
     2fc:	2e3cdce7 	fmul	v7.2s, v7.2s, v28.2s
     300:	fd000846 	str	d6, [x2, #16]
     304:	0e3dce27 	fmla	v7.2s, v17.2s, v29.2s
     308:	eb03005f 	cmp	x2, x3
     30c:	54ffff01 	b.ne	2ec <exp_rotation1+0x2ec>  // b.any
     310:	4b040422 	sub	w2, w1, w4, lsl #1
     314:	cb080fe8 	neg	x8, x8, lsl #3
     318:	51000442 	sub	w2, w2, #0x1
     31c:	fc256907 	str	d7, [x8, x5]
     320:	35ffec42 	cbnz	w2, a8 <exp_rotation1+0xa8>
     324:	bd40001e 	ldr	s30, [x0]
     328:	bd400805 	ldr	s5, [x0, #8]
     32c:	1e3e0839 	fmul	s25, s1, s30
     330:	1f056419 	fmadd	s25, s0, s5, s25
     334:	1e3f08a5 	fmul	s5, s5, s31
     338:	1f1e1405 	fmadd	s5, s0, s30, s5
     33c:	bd000819 	str	s25, [x0, #8]
     340:	bd000005 	str	s5, [x0]
     344:	d65f03c0 	ret
     348:	4b020025 	sub	w5, w1, w2
     34c:	710000bf 	cmp	w5, #0x0
     350:	54ffeacd 	b.le	a8 <exp_rotation1+0xa8>
     354:	d37e7c44 	ubfiz	x4, x2, #2, #32
     358:	0420e3e3 	cntb	x3
     35c:	8b030086 	add	x6, x4, x3
     360:	8b040004 	add	x4, x0, x4
     364:	f10000df 	cmp	x6, #0x0
     368:	8b030003 	add	x3, x0, x3
     36c:	fa43c082 	ccmp	x4, x3, #0x2, gt
     370:	93407c46 	sxtw	x6, w2
     374:	540018c3 	b.cc	68c <exp_rotation1+0x68c>  // b.lo, b.ul, b.last
     378:	d2800003 	mov	x3, #0x0                   	// #0
     37c:	04a0e3e7 	cntw	x7
     380:	05242018 	mov	z24.s, s0
     384:	05242024 	mov	z4.s, s1
     388:	052423e2 	mov	z2.s, s31
     38c:	25a50fe7 	whilelo	p7.s, wzr, w5
     390:	a5435c93 	ld1w	{z19.s}, p7/z, [x4, x3, lsl #2]
     394:	a5435c03 	ld1w	{z3.s}, p7/z, [x0, x3, lsl #2]
     398:	0420bf1e 	movprfx	z30, z24
     39c:	65829e7e 	fmul	z30.s, p7/m, z30.s, z19.s
     3a0:	0420bf11 	movprfx	z17, z24
     3a4:	65829c71 	fmul	z17.s, p7/m, z17.s, z3.s
     3a8:	65a31c9e 	fmla	z30.s, p7/m, z4.s, z3.s
     3ac:	65b31c51 	fmla	z17.s, p7/m, z2.s, z19.s
     3b0:	e5435c9e 	st1w	{z30.s}, p7, [x4, x3, lsl #2]
     3b4:	e5435c11 	st1w	{z17.s}, p7, [x0, x3, lsl #2]
     3b8:	8b070063 	add	x3, x3, x7
     3bc:	25a50c67 	whilelo	p7.s, w3, w5
     3c0:	54fffe81 	b.ne	390 <exp_rotation1+0x390>  // b.any
     3c4:	4b0200a5 	sub	w5, w5, w2
     3c8:	710004a7 	subs	w7, w5, #0x1
     3cc:	8b25c803 	add	x3, x0, w5, sxtw #2
     3d0:	d1001063 	sub	x3, x3, #0x4
     3d4:	54ffe6a4 	b.mi	a8 <exp_rotation1+0xa8>  // b.first
     3d8:	71000cff 	cmp	w7, #0x3
     3dc:	04a0e3e8 	cntw	x8
     3e0:	51000504 	sub	w4, w8, #0x1
     3e4:	7a4480e0 	ccmp	w7, w4, #0x0, hi	// hi = pmore
     3e8:	54001723 	b.cc	6cc <exp_rotation1+0x6cc>  // b.lo, b.ul, b.last
     3ec:	93407c21 	sxtw	x1, w1
     3f0:	04bf57e4 	rdvl	x4, #-1
     3f4:	cb224422 	sub	x2, x1, w2, uxtw #1
     3f8:	8b0200c9 	add	x9, x6, x2
     3fc:	8b020881 	add	x1, x4, x2, lsl #2
     400:	8b09088a 	add	x10, x4, x9, lsl #2
     404:	d37ef529 	lsl	x9, x9, #2
     408:	eb02095f 	cmp	x10, x2, lsl #2
     40c:	fa49b020 	ccmp	x1, x9, #0x0, lt	// lt = tstop
     410:	540015eb 	b.lt	6cc <exp_rotation1+0x6cc>  // b.tstop
     414:	8b010001 	add	x1, x0, x1
     418:	4b0800a9 	sub	w9, w5, w8
     41c:	05242019 	mov	z25.s, s0
     420:	8b0a0000 	add	x0, x0, x10
     424:	52800002 	mov	w2, #0x0                   	// #0
     428:	05242034 	mov	z20.s, s1
     42c:	052423fa 	mov	z26.s, s31
     430:	2518e3e7 	ptrue	p7.b
     434:	d503201f 	nop
     438:	d503201f 	nop
     43c:	d503201f 	nop
     440:	a540bc27 	ld1w	{z7.s}, p7/z, [x1]
     444:	a540bc05 	ld1w	{z5.s}, p7/z, [x0]
     448:	05b838e7 	rev	z7.s, z7.s
     44c:	05b838a5 	rev	z5.s, z5.s
     450:	65870a86 	fmul	z6.s, z20.s, z7.s
     454:	65a51f26 	fmla	z6.s, p7/m, z25.s, z5.s
     458:	05b838c6 	rev	z6.s, z6.s
     45c:	e540fc06 	st1w	{z6.s}, p7, [x0]
     460:	65850b45 	fmul	z5.s, z26.s, z5.s
     464:	0b080042 	add	w2, w2, w8
     468:	65a71f25 	fmla	z5.s, p7/m, z25.s, z7.s
     46c:	05b838a5 	rev	z5.s, z5.s
     470:	e540fc25 	st1w	{z5.s}, p7, [x1]
     474:	8b040000 	add	x0, x0, x4
     478:	8b040021 	add	x1, x1, x4
     47c:	6b09005f 	cmp	w2, w9
     480:	54fffe09 	b.ls	440 <exp_rotation1+0x440>  // b.plast
     484:	cb224860 	sub	x0, x3, w2, uxtw #2
     488:	4b0200e1 	sub	w1, w7, w2
     48c:	6b05005f 	cmp	w2, w5
     490:	54ffe0c0 	b.eq	a8 <exp_rotation1+0xa8>  // b.none
     494:	cb214801 	sub	x1, x0, w1, uxtw #2
     498:	d503201f 	nop
     49c:	d503201f 	nop
     4a0:	bd400004 	ldr	s4, [x0]
     4a4:	aa0003e2 	mov	x2, x0
     4a8:	bc667802 	ldr	s2, [x0, x6, lsl #2]
     4ac:	1e240823 	fmul	s3, s1, s4
     4b0:	1f020c03 	fmadd	s3, s0, s2, s3
     4b4:	1e3f0842 	fmul	s2, s2, s31
     4b8:	1f040802 	fmadd	s2, s0, s4, s2
     4bc:	bc267803 	str	s3, [x0, x6, lsl #2]
     4c0:	bc1fc402 	str	s2, [x0], #-4
     4c4:	eb01005f 	cmp	x2, x1
     4c8:	54fffec1 	b.ne	4a0 <exp_rotation1+0x4a0>  // b.any
     4cc:	d65f03c0 	ret
     4d0:	53017c28 	lsr	w8, w1, #1
     4d4:	91002002 	add	x2, x0, #0x8
     4d8:	51000903 	sub	w3, w8, #0x2
     4dc:	0e04041d 	dup	v29.2s, v0.s[0]
     4e0:	0e0407fc 	dup	v28.2s, v31.s[0]
     4e4:	0e04043b 	dup	v27.2s, v1.s[0]
     4e8:	fd400005 	ldr	d5, [x0]
     4ec:	8b234c43 	add	x3, x2, w3, uxtw #3
     4f0:	51001029 	sub	w9, w1, #0x4
     4f4:	aa0003e2 	mov	x2, x0
     4f8:	d503201f 	nop
     4fc:	d503201f 	nop
     500:	fd40045a 	ldr	d26, [x2, #8]
     504:	2e3cdf44 	fmul	v4.2s, v26.2s, v28.2s
     508:	0e3dcca4 	fmla	v4.2s, v5.2s, v29.2s
     50c:	2e3bdca5 	fmul	v5.2s, v5.2s, v27.2s
     510:	0e3dcf45 	fmla	v5.2s, v26.2s, v29.2s
     514:	fc008444 	str	d4, [x2], #8
     518:	eb03005f 	cmp	x2, x3
     51c:	54ffff21 	b.ne	500 <exp_rotation1+0x500>  // b.any
     520:	121f7925 	and	w5, w9, #0xfffffffe
     524:	51000827 	sub	w7, w1, #0x2
     528:	110008a5 	add	w5, w5, #0x2
     52c:	fd000045 	str	d5, [x2]
     530:	6b0500ff 	cmp	w7, w5
     534:	54ffeb2d 	b.le	298 <exp_rotation1+0x298>
     538:	4b0500e7 	sub	w7, w7, w5
     53c:	710004ff 	cmp	w7, #0x1
     540:	54ffe980 	b.eq	270 <exp_rotation1+0x270>  // b.none
     544:	d37e7ca2 	ubfiz	x2, x5, #2, #32
     548:	53017ce4 	lsr	w4, w7, #1
     54c:	91002043 	add	x3, x2, #0x8
     550:	8b020006 	add	x6, x0, x2
     554:	8b030003 	add	x3, x0, x3
     558:	d37df084 	lsl	x4, x4, #3
     55c:	fc626818 	ldr	d24, [x0, x2]
     560:	d2800002 	mov	x2, #0x0                   	// #0
     564:	2e3bdf16 	fmul	v22.2s, v24.2s, v27.2s
     568:	fc626877 	ldr	d23, [x3, x2]
     56c:	0e3dcef6 	fmla	v22.2s, v23.2s, v29.2s
     570:	2e37df97 	fmul	v23.2s, v28.2s, v23.2s
     574:	0e3dcf17 	fmla	v23.2s, v24.2s, v29.2s
     578:	fc226876 	str	d22, [x3, x2]
     57c:	0eb61ed8 	mov	v24.8b, v22.8b
     580:	fc2268d7 	str	d23, [x6, x2]
     584:	91002042 	add	x2, x2, #0x8
     588:	eb04005f 	cmp	x2, x4
     58c:	54fffec1 	b.ne	564 <exp_rotation1+0x564>  // b.any
     590:	36000707 	tbz	w7, #0, 670 <exp_rotation1+0x670>
     594:	121f78e7 	and	w7, w7, #0xfffffffe
     598:	0b0700a5 	add	w5, w5, w7
     59c:	17ffff35 	b	270 <exp_rotation1+0x270>
     5a0:	53027c28 	lsr	w8, w1, #2
     5a4:	91004004 	add	x4, x0, #0x10
     5a8:	51000903 	sub	w3, w8, #0x2
     5ac:	aa0003e2 	mov	x2, x0
     5b0:	3dc00004 	ldr	q4, [x0]
     5b4:	8b235083 	add	x3, x4, w3, uxtw #4
     5b8:	4e040416 	dup	v22.4s, v0.s[0]
     5bc:	51002029 	sub	w9, w1, #0x8
     5c0:	4e0407f7 	dup	v23.4s, v31.s[0]
     5c4:	4e040435 	dup	v21.4s, v1.s[0]
     5c8:	3dc00442 	ldr	q2, [x2, #16]
     5cc:	6e37dc54 	fmul	v20.4s, v2.4s, v23.4s
     5d0:	4e36cc94 	fmla	v20.4s, v4.4s, v22.4s
     5d4:	6e35dc84 	fmul	v4.4s, v4.4s, v21.4s
     5d8:	3c810454 	str	q20, [x2], #16
     5dc:	4e36cc44 	fmla	v4.4s, v2.4s, v22.4s
     5e0:	eb03005f 	cmp	x2, x3
     5e4:	54ffff21 	b.ne	5c8 <exp_rotation1+0x5c8>  // b.any
     5e8:	121e7525 	and	w5, w9, #0xfffffffc
     5ec:	5100102a 	sub	w10, w1, #0x4
     5f0:	110010a5 	add	w5, w5, #0x4
     5f4:	3d800044 	str	q4, [x2]
     5f8:	6b05015f 	cmp	w10, w5
     5fc:	54ffdacd 	b.le	154 <exp_rotation1+0x154>
     600:	4b050147 	sub	w7, w10, w5
     604:	510004e2 	sub	w2, w7, #0x1
     608:	7100085f 	cmp	w2, #0x2
     60c:	54ffd5c9 	b.ls	c4 <exp_rotation1+0xc4>  // b.plast
     610:	d37e7ca2 	ubfiz	x2, x5, #2, #32
     614:	53027ce4 	lsr	w4, w7, #2
     618:	91004043 	add	x3, x2, #0x10
     61c:	8b020006 	add	x6, x0, x2
     620:	8b030003 	add	x3, x0, x3
     624:	d37cec84 	lsl	x4, x4, #4
     628:	3ce26812 	ldr	q18, [x0, x2]
     62c:	d2800002 	mov	x2, #0x0                   	// #0
     630:	3ce26863 	ldr	q3, [x3, x2]
     634:	6e35de50 	fmul	v16.4s, v18.4s, v21.4s
     638:	4e36cc70 	fmla	v16.4s, v3.4s, v22.4s
     63c:	6e37dc63 	fmul	v3.4s, v3.4s, v23.4s
     640:	3ca26870 	str	q16, [x3, x2]
     644:	4e36ce43 	fmla	v3.4s, v18.4s, v22.4s
     648:	4eb01e12 	mov	v18.16b, v16.16b
     64c:	3ca268c3 	str	q3, [x6, x2]
     650:	91004042 	add	x2, x2, #0x10
     654:	eb04005f 	cmp	x2, x4
     658:	54fffec1 	b.ne	630 <exp_rotation1+0x630>  // b.any
     65c:	f24004ff 	tst	x7, #0x3
     660:	540000e0 	b.eq	67c <exp_rotation1+0x67c>  // b.none
     664:	121e74e7 	and	w7, w7, #0xfffffffc
     668:	0b0700a5 	add	w5, w5, w7
     66c:	17fffe96 	b	c4 <exp_rotation1+0xc4>
     670:	7100143f 	cmp	w1, #0x5
     674:	54ffe221 	b.ne	2b8 <exp_rotation1+0x2b8>  // b.any
     678:	17ffff2b 	b	324 <exp_rotation1+0x324>
     67c:	51002422 	sub	w2, w1, #0x9
     680:	7100085f 	cmp	w2, #0x2
     684:	54ffd78c 	b.gt	174 <exp_rotation1+0x174>
     688:	17fffed6 	b	1e0 <exp_rotation1+0x1e0>
     68c:	8b254804 	add	x4, x0, w5, uxtw #2
     690:	aa0003e3 	mov	x3, x0
     694:	d503201f 	nop
     698:	d503201f 	nop
     69c:	d503201f 	nop
     6a0:	bd400067 	ldr	s7, [x3]
     6a4:	bc667866 	ldr	s6, [x3, x6, lsl #2]
     6a8:	1e270825 	fmul	s5, s1, s7
     6ac:	1f061405 	fmadd	s5, s0, s6, s5
     6b0:	1e3f08c6 	fmul	s6, s6, s31
     6b4:	1f071806 	fmadd	s6, s0, s7, s6
     6b8:	bc267865 	str	s5, [x3, x6, lsl #2]
     6bc:	bc004466 	str	s6, [x3], #4
     6c0:	eb04007f 	cmp	x3, x4
     6c4:	54fffee1 	b.ne	6a0 <exp_rotation1+0x6a0>  // b.any
     6c8:	17ffff3f 	b	3c4 <exp_rotation1+0x3c4>
     6cc:	aa0303e0 	mov	x0, x3
     6d0:	cb274867 	sub	x7, x3, w7, uxtw #2
     6d4:	d503201f 	nop
     6d8:	d503201f 	nop
     6dc:	d503201f 	nop
     6e0:	bd400013 	ldr	s19, [x0]
     6e4:	aa0003e1 	mov	x1, x0
     6e8:	bc66781e 	ldr	s30, [x0, x6, lsl #2]
     6ec:	1e330831 	fmul	s17, s1, s19
     6f0:	1f1e4411 	fmadd	s17, s0, s30, s17
     6f4:	1e3f0bde 	fmul	s30, s30, s31
     6f8:	1f13781e 	fmadd	s30, s0, s19, s30
     6fc:	bc267811 	str	s17, [x0, x6, lsl #2]
     700:	bc1fc41e 	str	s30, [x0], #-4
     704:	eb07003f 	cmp	x1, x7
     708:	54fffec1 	b.ne	6e0 <exp_rotation1+0x6e0>  // b.any
     70c:	d65f03c0 	ret

0000000000000710 <exp_rotation.part.0.constprop.0>:
