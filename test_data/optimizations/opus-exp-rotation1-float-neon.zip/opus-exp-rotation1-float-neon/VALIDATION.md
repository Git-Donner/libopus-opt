# exp_rotation1 验证记录

工具为 AArch64 GCC 14.2、QEMU 10.0.13，以及云端本机 x86_64 GCC 14.2。ARM 浮点对照与候选库由 CMake 独立构建，基础选项为 `-O3 -march=armv8.2-a+sve -fno-semantic-interposition -fvisibility=hidden`。QEMU 的 SVE 测试使用 `-cpu max,sve-max-vq=2`。

| 检查 | 结果 |
|---|---|
| 内部 stride 专项，默认 `-O3` | **27,856/27,856** 组与原标量逐位一致 |
| 内部 stride 专项，`-ffp-contract=off` | **27,856/27,856** 组逐位一致 |
| AArch64 基线 ISA，QEMU 禁用 SVE | **27,856/27,856** 组通过，证明该旋转可用 NEON 执行 |
| UBSan | **27,856/27,856** 组通过，无诊断；检查的是专项测试路径 |
| ARM 浮点端到端 | 48 kHz，单/双声道 × 2.5/10/20 ms 共 6 项，**830 个编码包**逐字节一致；final range 与解码 PCM 一致 |
| 原有逆旋转测试 | `celt/tests/test_unit_rotation.c` 四组均通过 |
| 自带 API、padding 测试 | AArch64/QEMU 和 x86_64 各 2/2 通过 |
| AArch64 定点 | 静态库构建通过，优化分支未编入 |
| 叠加原有 PVQ SVE256 | 构建通过；算子 12,016 组、配对编码 300 帧通过；`actual256=11241` |

专项验证覆盖 stride=1/2/4、其他步长 3/5/8/11 的原有回退、0 至 256 范围内的有效长度、多个旋转系数、正负零、确定生成的数据和守护页。优化路径测试了短长度和长度余数。在 6 项端到端对照中，编码由两个独立库产生。逐文件比较 `opus_demo` 的码流输出（含 final range 字段）及各自的解码 PCM。

归档中 `validation/exp_rotation1-aarch64.asm` 是实际从 ARM 目标对象提取的反汇编。`fmul/fmla v*.2s` 和 `fmul/fmla v*.4s` 分别为两路和四路旋转。以上是编译及功能结果。ARM 服务器上的性能收益需用原生运行测量。
