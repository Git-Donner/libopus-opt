/***********************************************************************
Copyright (c) 2006-2011, Skype Limited. All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
- Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
- Neither the name of Internet Society, IETF or IETF Trust, nor the
names of specific contributors, may be used to endorse or promote
products derived from this software without specific prior written
permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
***********************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "main.h"

#if defined(__aarch64__) && defined(__AARCH64EL__) && defined(__ARM_NEON) && \
    defined(OPUS_ARM_PRESUME_NEON_INTR) && \
    !defined(FIXED_DEBUG) && !defined(silk_MACRO_COUNT)
#define SILK_VQ_WMAT_EC_NEON 1
#include <arm_neon.h>

/* Load four bytes without requiring alignment or readable padding. */
static OPUS_INLINE int32x4_t silk_vq_load_u8x4(const opus_uint8 *values)
{
    opus_uint32 packed;
    uint16x8_t widened;
    silk_memcpy(&packed, values, sizeof(packed));
    widened = vmovl_u8(vcreate_u8(packed));
    return vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(widened)));
}

/* Match silk_lin2log, including the CLZ and fractional part for zero. */
static OPUS_INLINE int32x4_t silk_vq_log_residual(int32x4_t residual_Q15)
{
    uint32x4_t bits = vreinterpretq_u32_s32(residual_Q15);
    int32x4_t lz = vreinterpretq_s32_u32(vclzq_u32(bits));
    uint32x4_t normalized = vshlq_u32(bits, lz);
    int32x4_t frac = vreinterpretq_s32_u32(vandq_u32(vshrq_n_u32(normalized, 24),
                                                   vdupq_n_u32(127)));
    int32x4_t curve = vmulq_s32(frac, vsubq_s32(vdupq_n_s32(128), frac));
    int32x4_t correction = vshrq_n_s32(vmulq_n_s32(curve, 179), 16);
    /* The caller needs silk_lin2log(residual_Q15) - (15 << 7). */
    return vaddq_s32(vaddq_s32(frac, correction),
                     vshlq_n_s32(vsubq_s32(vdupq_n_s32(16), lz), 7));
}

/* Each lane scores a complete codeword. Return -1 if all candidates are invalid. */
static opus_int silk_VQ_WMat_EC_neon(
    opus_int32 *res_nrg_Q15, opus_int32 *rate_dist_Q8,
    const opus_int32 *XX_Q17, const opus_int32 *xX_Q17,
    const opus_int8 *cb_Q7, const opus_uint8 *cb_gain_Q7, const opus_uint8 *cl_Q5,
    opus_int subfr_len, opus_int32 max_gain_Q7, opus_int L)
{
    /* The second table starts at byte 4 of the same 20-byte block. */
    const uint8x16_t coeff0123 = { 0, 5, 10, 15, 1, 6, 11, 28,
                                  2, 7, 12, 29, 3, 8, 13, 30 };
    const uint8x8_t coeff4 = { 4, 9, 14, 31, 255, 255, 255, 255 };
    const int32x4_t minus_one = vdupq_n_s32(-1);
    const int32x4_t zero = vdupq_n_s32(0);
    int32x4_t index = { 0, 1, 2, 3 };
    int32x4_t best_index = minus_one;
    int32x4_t best_rate_Q8 = vdupq_n_s32(silk_int32_MAX);
    int32x4_t best_residual_Q15 = vdupq_n_s32(silk_int32_MAX);
    opus_int32 neg_xX_Q24[5];
    opus_int32 minimum_rate_Q8;
    opus_int k, winner;

    for (k = 0; k < 5; k++)
        neg_xX_Q24[k] = -silk_LSHIFT32(xX_Q17[k], 7);

    for (k = 0; k < L; k += 4, cb_Q7 += 4 * LTP_ORDER) {
        int8x16x2_t table;
        int8x16_t packed;
        int16x8_t low, high;
        int32x4_t b0, b1, b2, b3, b4, row_Q24, sum_Q15;
        int32x4_t gains_Q7, penalty_Q15, residual_Q15, rate_Q8;
        uint32x4_t better;

        table.val[0] = vld1q_s8(cb_Q7);
        table.val[1] = vld1q_s8(cb_Q7 + 4);
        packed = vqtbl2q_s8(table, coeff0123);
        low = vmovl_s8(vget_low_s8(packed));
        high = vmovl_high_s8(packed);
        b0 = vmovl_s16(vget_low_s16(low));
        b1 = vmovl_high_s16(low);
        b2 = vmovl_s16(vget_low_s16(high));
        b3 = vmovl_high_s16(high);
        b4 = vmovl_s16(vget_low_s16(vmovl_s8(vqtbl2_s8(table, coeff4))));

        /* SQDMULH with a signed byte coefficient shifted by 15 implements
           (row * coefficient) >> 16 exactly and cannot saturate. Keep each
           row's truncation separate as in silk_SMLAWB. */
        row_Q24 = vmlaq_n_s32(vdupq_n_s32(neg_xX_Q24[0]), b1, XX_Q17[1]);
        row_Q24 = vmlaq_n_s32(row_Q24, b2, XX_Q17[2]);
        row_Q24 = vmlaq_n_s32(row_Q24, b3, XX_Q17[3]);
        row_Q24 = vmlaq_n_s32(row_Q24, b4, XX_Q17[4]);
        row_Q24 = vmlaq_n_s32(vshlq_n_s32(row_Q24, 1), b0, XX_Q17[0]);
        sum_Q15 = vaddq_s32(vdupq_n_s32(SILK_FIX_CONST(1.001, 15)),
                            vqdmulhq_s32(row_Q24, vshlq_n_s32(b0, 15)));

        row_Q24 = vmlaq_n_s32(vdupq_n_s32(neg_xX_Q24[1]), b2, XX_Q17[7]);
        row_Q24 = vmlaq_n_s32(row_Q24, b3, XX_Q17[8]);
        row_Q24 = vmlaq_n_s32(row_Q24, b4, XX_Q17[9]);
        row_Q24 = vmlaq_n_s32(vshlq_n_s32(row_Q24, 1), b1, XX_Q17[6]);
        sum_Q15 = vaddq_s32(sum_Q15, vqdmulhq_s32(row_Q24, vshlq_n_s32(b1, 15)));

        row_Q24 = vmlaq_n_s32(vdupq_n_s32(neg_xX_Q24[2]), b3, XX_Q17[13]);
        row_Q24 = vmlaq_n_s32(row_Q24, b4, XX_Q17[14]);
        row_Q24 = vmlaq_n_s32(vshlq_n_s32(row_Q24, 1), b2, XX_Q17[12]);
        sum_Q15 = vaddq_s32(sum_Q15, vqdmulhq_s32(row_Q24, vshlq_n_s32(b2, 15)));

        row_Q24 = vmlaq_n_s32(vdupq_n_s32(neg_xX_Q24[3]), b4, XX_Q17[19]);
        row_Q24 = vmlaq_n_s32(vshlq_n_s32(row_Q24, 1), b3, XX_Q17[18]);
        sum_Q15 = vaddq_s32(sum_Q15, vqdmulhq_s32(row_Q24, vshlq_n_s32(b3, 15)));

        row_Q24 = vmlaq_n_s32(vdupq_n_s32(silk_LSHIFT32(neg_xX_Q24[4], 1)), b4, XX_Q17[24]);
        sum_Q15 = vaddq_s32(sum_Q15, vqdmulhq_s32(row_Q24, vshlq_n_s32(b4, 15)));

        gains_Q7 = silk_vq_load_u8x4(cb_gain_Q7 + k);
        penalty_Q15 = vshlq_n_s32(vmaxq_s32(vsubq_s32(gains_Q7, vdupq_n_s32(max_gain_Q7)), zero), 11);
        /* Invalid lanes are scored speculatively and discarded by the mask below. */
        residual_Q15 = vreinterpretq_s32_u32(vaddq_u32(vreinterpretq_u32_s32(sum_Q15),
                                                        vreinterpretq_u32_s32(penalty_Q15)));
        rate_Q8 = vmlaq_n_s32(vshlq_n_s32(silk_vq_load_u8x4(cl_Q5 + k), 2),
                              silk_vq_log_residual(residual_Q15), (opus_int16)subfr_len);

        better = vandq_u32(vcgeq_s32(sum_Q15, zero), vcleq_s32(rate_Q8, best_rate_Q8));
        best_rate_Q8 = vbslq_s32(better, rate_Q8, best_rate_Q8);
        best_residual_Q15 = vbslq_s32(better, residual_Q15, best_residual_Q15);
        best_index = vbslq_s32(better, index, best_index);
        index = vaddq_s32(index, vdupq_n_s32(4));
    }

    minimum_rate_Q8 = vminvq_s32(best_rate_Q8);
    *rate_dist_Q8 = minimum_rate_Q8;
    /* The scalar <= update chooses the last codeword on equal cost. */
    winner = vmaxvq_s32(vbslq_s32(vceqq_s32(best_rate_Q8, vdupq_n_s32(minimum_rate_Q8)),
                                  best_index, minus_one));
    *res_nrg_Q15 = vmaxvq_s32(vbslq_s32(vceqq_s32(best_index, vdupq_n_s32(winner)),
                                       best_residual_Q15, vdupq_n_s32(silk_int32_MIN)));
    return winner;
}
#endif

/* Entropy constrained matrix-weighted VQ, hard-coded to 5-element vectors, for a single input data vector */
static void silk_VQ_WMat_EC_scalar(
    opus_int8                   *ind,                           /* O    index of best codebook vector               */
    opus_int32                  *res_nrg_Q15,                   /* O    best residual energy                        */
    opus_int32                  *rate_dist_Q8,                  /* O    best total bitrate                          */
    opus_int                    *gain_Q7,                       /* O    sum of absolute LTP coefficients            */
    const opus_int32            *XX_Q17,                        /* I    correlation matrix                          */
    const opus_int32            *xX_Q17,                        /* I    correlation vector                          */
    const opus_int8             *cb_Q7,                         /* I    codebook                                    */
    const opus_uint8            *cb_gain_Q7,                    /* I    codebook effective gain                     */
    const opus_uint8            *cl_Q5,                         /* I    code length for each codebook vector        */
    const opus_int              subfr_len,                      /* I    number of samples per subframe              */
    const opus_int32            max_gain_Q7,                    /* I    maximum sum of absolute LTP coefficients    */
    const opus_int              L                               /* I    number of vectors in codebook               */
)
{
    opus_int   k, gain_tmp_Q7;
    const opus_int8 *cb_row_Q7;
    opus_int32 neg_xX_Q24[ 5 ];
    opus_int32 sum1_Q15, sum2_Q24;
    opus_int32 bits_res_Q8, bits_tot_Q8;

    /* Negate and convert to new Q domain */
    neg_xX_Q24[ 0 ] = -silk_LSHIFT32( xX_Q17[ 0 ], 7 );
    neg_xX_Q24[ 1 ] = -silk_LSHIFT32( xX_Q17[ 1 ], 7 );
    neg_xX_Q24[ 2 ] = -silk_LSHIFT32( xX_Q17[ 2 ], 7 );
    neg_xX_Q24[ 3 ] = -silk_LSHIFT32( xX_Q17[ 3 ], 7 );
    neg_xX_Q24[ 4 ] = -silk_LSHIFT32( xX_Q17[ 4 ], 7 );

    /* Loop over codebook */
    *rate_dist_Q8 = silk_int32_MAX;
    *res_nrg_Q15 = silk_int32_MAX;
    cb_row_Q7 = cb_Q7;
    /* If things go really bad, at least *ind is set to something safe. */
    *ind = 0;
    for( k = 0; k < L; k++ ) {
        opus_int32 penalty;
        gain_tmp_Q7 = cb_gain_Q7[k];
        /* Weighted rate */
        /* Quantization error: 1 - 2 * xX * cb + cb' * XX * cb */
        sum1_Q15 = SILK_FIX_CONST( 1.001, 15 );

        /* Penalty for too large gain */
        penalty = silk_LSHIFT32( silk_max( silk_SUB32( gain_tmp_Q7, max_gain_Q7 ), 0 ), 11 );

        /* first row of XX_Q17 */
        sum2_Q24 = silk_MLA( neg_xX_Q24[ 0 ], XX_Q17[  1 ], cb_row_Q7[ 1 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  2 ], cb_row_Q7[ 2 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  3 ], cb_row_Q7[ 3 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  4 ], cb_row_Q7[ 4 ] );
        sum2_Q24 = silk_LSHIFT32( sum2_Q24, 1 );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  0 ], cb_row_Q7[ 0 ] );
        sum1_Q15 = silk_SMLAWB( sum1_Q15,        sum2_Q24,  cb_row_Q7[ 0 ] );

        /* second row of XX_Q17 */
        sum2_Q24 = silk_MLA( neg_xX_Q24[ 1 ], XX_Q17[  7 ], cb_row_Q7[ 2 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  8 ], cb_row_Q7[ 3 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  9 ], cb_row_Q7[ 4 ] );
        sum2_Q24 = silk_LSHIFT32( sum2_Q24, 1 );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[  6 ], cb_row_Q7[ 1 ] );
        sum1_Q15 = silk_SMLAWB( sum1_Q15,        sum2_Q24,  cb_row_Q7[ 1 ] );

        /* third row of XX_Q17 */
        sum2_Q24 = silk_MLA( neg_xX_Q24[ 2 ], XX_Q17[ 13 ], cb_row_Q7[ 3 ] );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[ 14 ], cb_row_Q7[ 4 ] );
        sum2_Q24 = silk_LSHIFT32( sum2_Q24, 1 );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[ 12 ], cb_row_Q7[ 2 ] );
        sum1_Q15 = silk_SMLAWB( sum1_Q15,        sum2_Q24,  cb_row_Q7[ 2 ] );

        /* fourth row of XX_Q17 */
        sum2_Q24 = silk_MLA( neg_xX_Q24[ 3 ], XX_Q17[ 19 ], cb_row_Q7[ 4 ] );
        sum2_Q24 = silk_LSHIFT32( sum2_Q24, 1 );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[ 18 ], cb_row_Q7[ 3 ] );
        sum1_Q15 = silk_SMLAWB( sum1_Q15,        sum2_Q24,  cb_row_Q7[ 3 ] );

        /* last row of XX_Q17 */
        sum2_Q24 = silk_LSHIFT32( neg_xX_Q24[ 4 ], 1 );
        sum2_Q24 = silk_MLA( sum2_Q24,        XX_Q17[ 24 ], cb_row_Q7[ 4 ] );
        sum1_Q15 = silk_SMLAWB( sum1_Q15,        sum2_Q24,  cb_row_Q7[ 4 ] );

        /* find best */
        if( sum1_Q15 >= 0 ) {
            /* Translate residual energy to bits using high-rate assumption (6 dB ==> 1 bit/sample) */
            bits_res_Q8 = silk_SMULBB( subfr_len, silk_lin2log( sum1_Q15 + penalty) - (15 << 7) );
            /* In the following line we reduce the codelength component by half ("-1"); seems to slightly improve quality */
            bits_tot_Q8 = silk_ADD_LSHIFT32( bits_res_Q8, cl_Q5[ k ], 3-1 );
            if( bits_tot_Q8 <= *rate_dist_Q8 ) {
                *rate_dist_Q8 = bits_tot_Q8;
                *res_nrg_Q15 = sum1_Q15 + penalty;
                *ind = (opus_int8)k;
                *gain_Q7 = gain_tmp_Q7;
            }
        }

        /* Go to next cbk vector */
        cb_row_Q7 += LTP_ORDER;
    }
}

void silk_VQ_WMat_EC_c(
    opus_int8 *ind, opus_int32 *res_nrg_Q15, opus_int32 *rate_dist_Q8, opus_int *gain_Q7,
    const opus_int32 *XX_Q17, const opus_int32 *xX_Q17, const opus_int8 *cb_Q7,
    const opus_uint8 *cb_gain_Q7, const opus_uint8 *cl_Q5, opus_int subfr_len,
    opus_int32 max_gain_Q7, opus_int L)
{
#ifdef SILK_VQ_WMAT_EC_NEON
    if (L >= 8 && L % 4 == 0) {
        opus_int winner = silk_VQ_WMat_EC_neon(res_nrg_Q15, rate_dist_Q8, XX_Q17, xX_Q17,
                                               cb_Q7, cb_gain_Q7, cl_Q5, subfr_len, max_gain_Q7, L);
        *ind = 0;
        if (winner >= 0) {
            *ind = (opus_int8)winner;
            *gain_Q7 = cb_gain_Q7[winner];
        }
#ifdef OPUS_CHECK_ASM
        {
            opus_int8 ind_c;
            opus_int32 res_c, rate_c;
            opus_int gain_c = -1;
            silk_VQ_WMat_EC_scalar(&ind_c, &res_c, &rate_c, &gain_c, XX_Q17, xX_Q17,
                                   cb_Q7, cb_gain_Q7, cl_Q5, subfr_len, max_gain_Q7, L);
            celt_assert(*ind == ind_c);
            celt_assert(*res_nrg_Q15 == res_c);
            celt_assert(*rate_dist_Q8 == rate_c);
            celt_assert((winner >= 0 ? *gain_Q7 : -1) == gain_c);
        }
#endif
        return;
    }
#endif
    silk_VQ_WMat_EC_scalar(ind, res_nrg_Q15, rate_dist_Q8, gain_Q7, XX_Q17, xX_Q17,
                           cb_Q7, cb_gain_Q7, cl_Q5, subfr_len, max_gain_Q7, L);
}
