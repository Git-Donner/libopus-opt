# libopus CELT pitch 和 SILK LTP 搜索的 128-bit NEON 优化

基于 Git-Donner/libopus-opt 提交 d5f57452c1880c50ab0b8c0800810ba5da98923b。
将 files/ 下的两个文件按相对路径放入源码根目录，或在源码根目录应用 opus-neon-pitch-ltp.patch。更新后重新编译静态库和测试 worker。

## 改动范围

- celt/pitch.c。AArch64 浮点 CELT 的 find_best_pitch 每组检查四个候选。滑动能量按原顺序更新。有潜在改进的组按原顺序更新前两名，保留交叉乘法和同分规则。
- silk/VQ_WMat_EC.c。AArch64 little-endian 的 SILK LTP 一次计算四个独立码字的矩阵代价和定点近似对数，用掩码选出获胜者，同分时取原顺序最后一个。常规 8、16、32 项码本都使用 SIMD。此整数算子由浮点和定点 SILK 共同使用。

沿用源码的 ARM NEON intrinsics 配置即可在 AArch64 启用这两个路径。SVE 构建也可使用本包；本包的新增向量代码使用 128-bit NEON。源码保留标量路径供其他构建使用。

## 正确性验证

- GCC 14.2 AArch64/QEMU。CELT 算子在 ARMv8-A、ARMv8.2-A+SVE、关闭 FMA 收缩、常用优化级别和 UBSan 等组合下，每个构建 104,000 例的两个索引均与原实现一致。输入尾部使用保护页。
- SILK 算子每个构建 194,398 例对照通过，其中 85,511 例符合 SIMD 路径条件。覆盖同分、零残差、全无效候选及只读合法长度边界，并验证定点构建、启用 OPUS_CHECK_ASM 和 UBSan。
- CELT、SILK、HYBRID 共 180 个端到端用例。ARMv8-A 浮点、ARMv8.2-A+SVE 浮点、ARMv8-A 定点、x86-64 浮点每个构建对照 15,840 帧。编码包、编码及解码最终 range 和解码 PCM 均逐位一致。ARM 定点测试采用了只启用 AArch64 intrinsics 的编译定义，以避开该源码 CMake 配置对 ARM32 汇编符号的依赖。
- Kunpeng 实机上的周期、分支预测和端到端收益需要在目标机测量。
