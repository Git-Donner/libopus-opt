#!/usr/bin/env python3
"""Balanced paired comparison of two copyable opus_perf_bench executables."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import bench


def paired_summary(pairs):
    """Geometric speedup and percentile bootstrap CI over independent pairs."""
    if not pairs or any(a <= 0 or b <= 0 or not math.isfinite(a + b) for a, b in pairs):
        raise ValueError("nonpositive or nonfinite paired times")
    logs = [math.log(a / b) for a, b in pairs]
    ratio = math.exp(statistics.mean(logs))
    ci = None
    if len(logs) >= 5:
        rng = random.Random(1729)
        draws = sorted(math.exp(statistics.mean(rng.choices(logs, k=len(logs))))
                       for _ in range(10000))
        ci = [draws[249], draws[9749]]
    verdict = "insufficient" if ci is None else (
        "faster" if ci[0] > 1 else "slower" if ci[1] < 1 else "inconclusive")
    return {"pairs": len(pairs), "baseline_mean_us": statistics.mean(a for a, _ in pairs),
            "candidate_mean_us": statistics.mean(b for _, b in pairs),
            "speedup_ratio": ratio, "paired_bootstrap_ci95": ci,
            "time_reduction_percent": 100 * (1 - 1 / ratio), "verdict": verdict}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def run_one(executable, config, cpu, fixtures, case, repeats, out, label):
    name = case["name"]
    encode = case["operation"] == "encode"
    command = [str(executable), "-c", str(config), "--cpu", str(cpu),
               "--fixtures-dir", str(fixtures), "--case", name, "--repeats", str(repeats),
               "--lib-name", label, "-o", str(out)]
    proc = subprocess.run(command, capture_output=True, text=True)
    out.mkdir(parents=True, exist_ok=True)
    (out / "console.log").write_text(proc.stdout + "\n" + proc.stderr, encoding="utf-8")
    if proc.returncode:
        raise RuntimeError(f"{label}/{name} failed (exit {proc.returncode}); see {out / 'console.log'}")
    markers = [line.split("=", 1)[1] for line in proc.stdout.splitlines()
               if line.startswith("RESULT_JSON=")]
    if len(markers) != 1:
        raise RuntimeError(f"{label}/{name}: missing unique result artifact")
    artifact = Path(markers[0])
    report = json.loads(artifact.read_text(encoding="utf-8"))
    if report.get("measurement_protocol") != bench.MEASUREMENT_PROTOCOL:
        raise RuntimeError(f"{label}/{name}: rebuild both benchmark executables with test_2")
    if (report.get("status") != "passed" or report.get("cpu") != cpu or
            len(report.get("results", [])) != 1):
        raise RuntimeError(f"{label}/{name}: invalid/failed report")
    row = report["results"][0]
    runs = row.get("runs", [])
    expected_schedule = "continuous" if encode else "independent"
    if (row.get("name") != name or row.get("case") != case or row.get("status") != "passed" or
            row.get("schedule") != expected_schedule or len(runs) != repeats):
        raise RuntimeError(f"{label}/{name}: incomplete case or different measurement schedule")
    frames = case["frames"]
    for run in runs:
        if (run.get("frames") != frames or len(run["samples_ns"]) != frames or
                run["total_ns"] <= 0 or not math.isfinite(run["total_ns"])):
            raise RuntimeError(f"{label}/{name}: invalid native sample count or duration")
    key = "pcm_hash" if encode else "packet_hash"
    workload = runs[0].get(key)
    if not workload or any(run.get(key) != workload for run in runs):
        raise RuntimeError(f"{label}/{name}: missing or inconsistent workload fingerprint ({key})")
    output_hash = (row["verification"] if encode else runs[0]).get("output_hash")
    if not isinstance(output_hash, str) or not output_hash:
        raise RuntimeError(f"{label}/{name}: missing verified output fingerprint")
    config_sha256 = report.get("config_sha256")
    if not config_sha256:
        raise RuntimeError(f"{label}/{name}: missing effective configuration fingerprint")
    return {"result_json": str(artifact), "workload": workload, "output_hash": output_hash,
            "config_sha256": config_sha256,
            "mean_us": sum(run["total_ns"] for run in runs) / (frames * repeats) / 1000}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("-c", "--config", required=True, type=Path)
    parser.add_argument("--cpu", required=True, type=int)
    parser.add_argument("--fixtures-dir", required=True, type=Path)
    parser.add_argument("--case", action="append", default=[], help="Select one or more named cases")
    parser.add_argument("--pairs", type=int, default=10)
    parser.add_argument("--repeats", type=int,
                        help="Continuous encode blocks per side of each pair (default: config repeats)")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--allow-output-differences", action="store_true",
                        help="Permit output hash differences after separate correctness/quality validation")
    parser.add_argument("-o", "--output-dir", type=Path, default=Path("output/compare"))
    args = parser.parse_args()
    if not 1 <= args.pairs <= 100:
        parser.error("--pairs must be in 1..100 (at least 5 for an interval)")
    if args.repeats is not None and not 1 <= args.repeats <= 1000:
        parser.error("--repeats must be in 1..1000")
    if args.cpu not in os.sched_getaffinity(0):
        parser.error("--cpu is outside this process's allowed affinity")
    config = bench.load_config(args.config)
    requested = set(args.case)
    known = {case["name"] for case in config["test_cases"]}
    if requested - known:
        parser.error("unknown selected cases: " + ", ".join(sorted(requested - known)))
    cases_to_compare = [case for case in config["test_cases"] if not requested or case["name"] in requested]
    encode_repeats = config["repeats"] if args.repeats is None else args.repeats
    for attr in ("baseline", "candidate", "config"):
        setattr(args, attr, getattr(args, attr).resolve(strict=True))
    args.fixtures_dir = args.fixtures_dir.resolve()
    hashes = {label: sha256(getattr(args, label)) for label in ("baseline", "candidate")}
    config_hash = sha256(args.config)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix="paired-", dir=args.output_dir.resolve()))
    schedule, collected = [], {case["name"]: [] for case in cases_to_compare}
    workloads, differences, artifacts = {}, [], []
    rng = random.Random(args.seed)
    # Randomize which version leads the first pair, then alternate AB/BA.
    lead = rng.randrange(2)
    for i in range(args.pairs):
        cases = cases_to_compare[:]
        rng.shuffle(cases)
        labels = ["baseline", "candidate"]
        if (i + lead) % 2:
            labels.reverse()
        for case in cases:
            if sha256(args.config) != config_hash:
                raise RuntimeError("configuration changed during comparison")
            name = case["name"]
            repeats = encode_repeats if case["operation"] == "encode" else 1
            readings = {}
            safe_case = hashlib.sha256(name.encode()).hexdigest()[:20]
            for label in labels:
                reading = run_one(getattr(args, label), args.config, args.cpu, args.fixtures_dir,
                                  case, repeats, out / f"pair-{i+1}" / safe_case / label, label)
                readings[label] = reading
                step = {"pair": i + 1, "case": name, "version": label, "repeats": repeats}
                schedule.append(step)
                artifacts.append({**step, "result_json": reading["result_json"]})
            a, b = readings["baseline"], readings["candidate"]
            workload = a["workload"]
            if workload != b["workload"]:
                raise RuntimeError(f"{name}: A/B workloads differ")
            if workloads.setdefault(name, workload) != workload:
                raise RuntimeError(f"{name}: workload changed between pairs")
            if a["output_hash"] != b["output_hash"]:
                differences.append({"pair": i + 1, "case": name})
                if not args.allow_output_differences:
                    raise RuntimeError(f"{name}: decoded output differs; validate correctness/quality before using --allow-output-differences")
            if a["config_sha256"] != b["config_sha256"]:
                raise RuntimeError("configuration fingerprint mismatch")
            at, bt = a["mean_us"], b["mean_us"]
            collected[name].append((at, bt))
            print(f"pair {i+1}/{args.pairs} {name}: A={at:.3f} B={bt:.3f} us/frame", flush=True)
    if any(sha256(getattr(args, label)) != value for label, value in hashes.items()):
        raise RuntimeError("a benchmark executable changed during the experiment")
    results = [{"name": name, **paired_summary(values)} for name, values in collected.items()]
    report = {"status": "passed", "cpu": args.cpu, "binary_sha256": hashes,
              "measurement_protocol": bench.MEASUREMENT_PROTOCOL,
              "config_sha256": config_hash, "schedule": schedule,
              "pairs": collected, "results": results, "output_differences": differences,
              "run_artifacts": artifacts,
              "interval_note": "Percentile bootstrap over independent session pairs in log space. Encode sessions contain continuous blocks; blocks are not separate pairs."}
    text = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)
    temp = out / "comparison.json.tmp"
    temp.write_text(text + "\n", encoding="utf-8")
    temp.replace(out / "comparison.json")
    headers = ("Case", "A mean us", "B mean us", "Speedup A/B", "95% interval", "Time reduction", "Result")
    rows = []
    for r in results:
        ci = r["paired_bootstrap_ci95"]
        interval = f"[{ci[0]:.3f}, {ci[1]:.3f}]" if ci else "insufficient pairs"
        rows.append((r["name"], f"{r['baseline_mean_us']:.3f}", f"{r['candidate_mean_us']:.3f}",
                     f"{r['speedup_ratio']:.3f}", interval, f"{r['time_reduction_percent']:.2f}%", r["verdict"]))
    print()
    bench.print_box_table(headers, rows)
    print(f"RESULT_JSON={out / 'comparison.json'}")
    if differences:
        print("WARNING: output hashes differ; speed comparisons require separate quality validation.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, RuntimeError, KeyError, bench.BenchError) as error:
        print(f"comparison failed: {error}", file=sys.stderr)
        sys.exit(1)
