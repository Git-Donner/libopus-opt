/* Copyright (c) 2010 Xiph.Org Foundation
 * Copyright (c) 2013 Parrot
 * Copyright (c) 2024 Arm Limited */
/*
   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   - Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   - Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
   OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "kiss_fft.h"
#include "mathops.h"
#include "mdct.h"
#include "pitch.h"
#include "vq.h"

#if defined(OPUS_HAVE_RTCD)

# if !defined(DISABLE_FLOAT_API)
#  if defined(OPUS_ARM_MAY_HAVE_NEON_INTR) && !defined(OPUS_ARM_PRESUME_NEON_INTR)
void (*const CELT_FLOAT2INT16_IMPL[OPUS_ARCHMASK+1])(const float * OPUS_RESTRICT in, short * OPUS_RESTRICT out, int cnt) = {
  celt_float2int16_c,   /* ARMv4 */
  celt_float2int16_c,   /* EDSP */
  celt_float2int16_c,   /* Media */
  celt_float2int16_neon,/* NEON */
  celt_float2int16_neon /* DOTPROD */
};

int (*const OPUS_LIMIT2_CHECKWITHIN1_IMPL[OPUS_ARCHMASK+1])(float * samples, int cnt) = {
  opus_limit2_checkwithin1_c,   /* ARMv4 */
  opus_limit2_checkwithin1_c,   /* EDSP */
  opus_limit2_checkwithin1_c,   /* Media */
  opus_limit2_checkwithin1_neon,/* NEON */
  opus_limit2_checkwithin1_neon /* DOTPROD */
};
#  endif
# endif

# if defined(OPUS_ARM_MAY_HAVE_NEON_INTR) && !defined(OPUS_ARM_PRESUME_NEON_INTR)
opus_val32 (*const CELT_INNER_PROD_IMPL[OPUS_ARCHMASK+1])(const opus_val16 *x, const opus_val16 *y, int N) = {
  celt_inner_prod_c,   /* ARMv4 */
  celt_inner_prod_c,   /* EDSP */
  celt_inner_prod_c,   /* Media */
  celt_inner_prod_neon,/* NEON */
  celt_inner_prod_neon /* DOTPROD */
};

void (*const DUAL_INNER_PROD_IMPL[OPUS_ARCHMASK+1])(const opus_val16 *x, const opus_val16 *y01, const opus_val16 *y02,
      int N, opus_val32 *xy1, opus_val32 *xy2) = {
  dual_inner_prod_c,   /* ARMv4 */
  dual_inner_prod_c,   /* EDSP */
  dual_inner_prod_c,   /* Media */
  dual_inner_prod_neon,/* NEON */
  dual_inner_prod_neon /* DOTPROD */
};
# endif

# if defined(FIXED_POINT)
#  if ((defined(OPUS_ARM_MAY_HAVE_NEON) && !defined(OPUS_ARM_PRESUME_NEON)) || \
    (defined(OPUS_ARM_MAY_HAVE_MEDIA) && !defined(OPUS_ARM_PRESUME_MEDIA)) || \
    (defined(OPUS_ARM_MAY_HAVE_EDSP) && !defined(OPUS_ARM_PRESUME_EDSP)))
opus_val32 (*const CELT_PITCH_XCORR_IMPL[OPUS_ARCHMASK+1])(const opus_val16 *,
    const opus_val16 *, opus_val32 *, int, int, int) = {
  celt_pitch_xcorr_c,               /* ARMv4 */
  MAY_HAVE_EDSP(celt_pitch_xcorr),  /* EDSP */
  MAY_HAVE_MEDIA(celt_pitch_xcorr), /* Media */
  MAY_HAVE_NEON(celt_pitch_xcorr),  /* NEON */
  MAY_HAVE_NEON(celt_pitch_xcorr)   /* DOTPROD */
};

#  endif
# else /* !FIXED_POINT */
#  if defined(OPUS_ARM_MAY_HAVE_NEON_INTR) && !defined(OPUS_ARM_PRESUME_NEON_INTR)
opus_val16 (*const OP_PVQ_SEARCH_IMPL[OPUS_ARCHMASK+1])(
    celt_norm *X, int *iy, int K, int N, int arch) = {
  op_pvq_search_c,                /* ARMv4 */
  op_pvq_search_c,                /* EDSP */
  op_pvq_search_c,                /* Media */
  op_pvq_search_neon,             /* NEON */
  op_pvq_search_neon              /* DOTPROD */
};

void (*const CELT_PITCH_XCORR_IMPL[OPUS_ARCHMASK+1])(const opus_val16 *,
    const opus_val16 *, opus_val32 *, int, int, int) = {
  celt_pitch_xcorr_c,              /* ARMv4 */
  celt_pitch_xcorr_c,              /* EDSP */
  celt_pitch_xcorr_c,              /* Media */
  celt_pitch_xcorr_float_neon,     /* Neon */
  celt_pitch_xcorr_float_neon      /* DOTPROD */
};

#   if defined(__aarch64__)
void (*const COMB_FILTER_CONST_IMPL[OPUS_ARCHMASK+1])(opus_val32 *y,
    opus_val32 *x, int T, int N, opus_val16 g10, opus_val16 g11, opus_val16 g12) = {
  comb_filter_const_c,             /* ARMv4 */
  comb_filter_const_c,             /* EDSP */
  comb_filter_const_c,             /* Media */
  comb_filter_const_neon,          /* Neon */
  comb_filter_const_neon           /* DOTPROD */
};

void (*const DEEMPHASIS_STEREO_SIMPLE_IMPL[OPUS_ARCHMASK+1])(celt_sig *in[],
    opus_res *pcm, int N, opus_val16 coef, celt_sig *mem) = {
  deemphasis_stereo_simple_c,      /* ARMv4 */
  deemphasis_stereo_simple_c,      /* EDSP */
  deemphasis_stereo_simple_c,      /* Media */
  deemphasis_stereo_simple_neon,   /* Neon */
  deemphasis_stereo_simple_neon    /* DOTPROD */
};

opus_val32 (*const CELT_DEEMPHASIS_IMPL[OPUS_ARCHMASK+1])(opus_res *y,
    const opus_val32 *x, opus_val16 coef0, opus_val32 m, int N) = {
  celt_deemphasis_c,               /* ARMv4 */
  celt_deemphasis_c,               /* EDSP */
  celt_deemphasis_c,               /* Media */
  celt_deemphasis_neon,            /* Neon */
  celt_deemphasis_neon             /* DOTPROD */
};

void (*const CLT_MDCT_BACKWARD_IMPL[OPUS_ARCHMASK+1])(const mdct_lookup *l,
    kiss_fft_scalar *in, kiss_fft_scalar * OPUS_RESTRICT out,
    const celt_coef * OPUS_RESTRICT window,
    int overlap, int shift, int stride, int arch) = {
  clt_mdct_backward_c,             /* ARMv4 */
  clt_mdct_backward_c,             /* EDSP */
  clt_mdct_backward_c,             /* Media */
  clt_mdct_backward_tx,            /* Neon */
  clt_mdct_backward_tx             /* DOTPROD */
};
#   endif /* __aarch64__ */
#  endif
# endif /* FIXED_POINT */

#if defined(FIXED_POINT) && defined(OPUS_HAVE_RTCD) && \
 defined(OPUS_ARM_MAY_HAVE_NEON_INTR) && !defined(OPUS_ARM_PRESUME_NEON_INTR)

void (*const XCORR_KERNEL_IMPL[OPUS_ARCHMASK + 1])(
         const opus_val16 *x,
         const opus_val16 *y,
         opus_val32       sum[4],
         int              len
) = {
  xcorr_kernel_c,                /* ARMv4 */
  xcorr_kernel_c,                /* EDSP */
  xcorr_kernel_c,                /* Media */
  xcorr_kernel_neon_fixed,       /* Neon */
  xcorr_kernel_neon_fixed        /* DOTPROD */
};

#endif

#endif /* OPUS_HAVE_RTCD */
